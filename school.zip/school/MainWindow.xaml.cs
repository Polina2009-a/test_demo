﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace school
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private school_bd _currentNed = new school_bd();
        schoolEntities db = new schoolEntities();

        public MainWindow()
        {
            InitializeComponent();
            bd_sch.ItemsSource = schoolEntities.GetContext().school_bd.ToList();
            Number.ItemsSource = schoolEntities.GetContext().school_bd.ToList();
            DataContext = _currentNed;
        }

        void Clear() //Очистка боксов
        {
            Name.Text = "";
            Name2.Text = "";
            Name3.Text = "";
            Number.Text = "";
            Ticket.Text = "";
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            schoolEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            bd_sch.ItemsSource = schoolEntities.GetContext().school_bd.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)  //Добавление
        {

            if (Name.Text != "" && Name2.Text != "" && Name3.Text != "" && Number.Text != "" && Ticket.Text != "")
            {
                _currentNed.Группа = Convert.ToDouble(Number.Text);
                db.school_bd.Add(_currentNed);
                upd_sav();
                Clear();
                MessageBox.Show("Успешно добавлено!");
      
            }
            else MessageBox.Show("Введите данные!");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //Изменение
        {
            int n = 0;
            school_bd User = new school_bd();
            if (id_izm.Text != "" &&  Name.Text != "" && Name2.Text != "" && Name3.Text != "" && Number.Text != "" && Ticket.Text != "")
            {
                foreach (var item in db.school_bd)
                {
                    if (item.ИД.ToString() == id_izm.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }

                if (n == 1)
                {
                    double n1 = Convert.ToDouble(Number.Text);
                    double m = Convert.ToDouble(Ticket.Text);
                    User.Имя = Name.Text;
                    User.Фамили = Name2.Text;
                    User.Отчество = Name3.Text;
                    User.Группа = n1;
                    User.Студ_билет = m;
                    upd_sav();
                    MessageBox.Show("Пользователь изменён!");
                    bd_sch.ItemsSource = schoolEntities.GetContext().school_bd.ToList();
                }
                else MessageBox.Show("Пользователь не найден!");
            }
            else MessageBox.Show("Введите ИД и данные!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Удаление
        {
            int n = 0;
            school_bd User = new school_bd();
            if (id_del.Text == null) MessageBox.Show("Введите ИД!");
            else
            {
                foreach (var item in db.school_bd)
                {
                    if (item.ИД.ToString() == id_del.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }
                if (n == 1)
                {
                    if (MessageBox.Show("Удалить пользователя?", "Удаление!",
                          MessageBoxButton.YesNo, MessageBoxImage.Warning).ToString() == "Yes"
                          && User != null)
                    {
                        db.school_bd.Remove(User);
                        upd_sav();
                        MessageBox.Show("Пользователь удален!");
                    }
                }
                else MessageBox.Show("Пользовател не найден!");
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //Aвторизация/проверка
        {
            int n = 0;
            if (Name.Text == "" && Name2.Text == "" && Name3.Text == "") MessageBox.Show("Введите данные!");
            else
            {
                foreach (var school in db.school_bd)
                {
                    if (Name.Text == school.Имя && Name2.Text == school.Фамили && Name3.Text == school.Отчество)
                    {
                        n = 1;
                        break;
                    }
                }
                if (n == 1)
                {
                    MessageBox.Show("Аккаун найден!");
                    Clear();
                }
                else MessageBox.Show("Аккаун не найден!");
            }
        }

        void search() //Поиск
        {
            var current_item = schoolEntities.GetContext().school_bd.ToList();
            current_item = current_item.Where(p => p.Группа.ToString().ToLower().Contains(serch.Text.ToLower())).ToList();
            bd_sch.ItemsSource = current_item;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            search();
        }

        private void Serch_TextChanged(object sender, TextChangedEventArgs e)
        {
            search();
        }
    }
}